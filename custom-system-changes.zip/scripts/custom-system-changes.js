
const MOD_ID = "custom-system-changes";
const LABEL = "Specific Magic Weapon";

/** Insert a labeled copy of the blank option (value="") into rune selectors */
function injectDuplicateBlank(selectRoot=document) {
  const selects = selectRoot.querySelectorAll('select[name^="system.runes.property"]');
  for (const sel of selects) {
    // Skip if we've already injected for this select
    if (sel.dataset.cscInjected === "1") continue;

    // Find the blank option
    const blank = sel.querySelector('option[value=""]');
    if (!blank) continue;

    // If a labeled copy we added already exists, mark and continue
    const exists = Array.from(sel.options).some(o => o.value === "" && o.textContent.trim() === LABEL);
    if (exists) { sel.dataset.cscInjected = "1"; continue; }

    // Clone the blank option and set its text
    const clone = blank.cloneNode(true);
    clone.textContent = LABEL;
    // Keep value="" intentionally; selecting it will behave like blank
    // Mark our clone so we could identify/remove later if needed
    clone.dataset.csc = "smw";

    // Insert clone directly after the original blank option (as second item)
    blank.insertAdjacentElement("afterend", clone);

    sel.dataset.cscInjected = "1";
  }
}

// Run on initial ready and whenever a PF2e actor sheet renders
Hooks.once("ready", () => {
  injectDuplicateBlank(document);

  // Re-patch after any actor sheet render
  Hooks.on("renderActorSheet", (_app, html) => {
    injectDuplicateBlank(html[0] ?? html);
  });
});
