
// === Custom System Changes v1.3.2 ===
if (!window.__CSC_BOOTED__) {
  window.__CSC_BOOTED__ = true;
  console.log("%c[CSC] script loaded", "color:#7bd; font-weight:700");

  const MOD_ID   = "custom-system-changes";
  const LABEL    = "Specific Magic Item";
  const MARKER   = "smi";
  const SELECTOR = 'select[name^="system.runes.property"]';
  const NAME_RX  = /^system\.runes\.property\.(\d+)/;

  const getSlotIndex = (sel) => {
    const m = NAME_RX.exec(sel?.name ?? "");
    return m ? Number(m[1]) : null;
  };

  function ensureOption(sel) {
    const blank = sel.querySelector('option[value=""]');
    if (!blank) return null;
    let clone = sel.querySelector(`option[value=""][data-csc="${MARKER}"]`);
    if (!clone) {
      clone = blank.cloneNode(true);
      clone.textContent = LABEL;
      clone.dataset.csc = MARKER;
      blank.insertAdjacentElement("afterend", clone);
    } else if (clone.textContent.trim() !== LABEL) {
      clone.textContent = LABEL;
    }
    return clone;
  }

  function readFlag(item) {
    const stored = item?.getFlag?.(MOD_ID, MARKER);
    if (Array.isArray(stored)) return stored.slice();
    if (stored === true) { try { item?.unsetFlag?.(MOD_ID, MARKER); } catch {} return []; }
    return [];
  }

  async function writeFlag(item, arr) {
    if (!item?.setFlag) return;
    if (!arr || arr.length === 0) { try { await item.unsetFlag(MOD_ID, MARKER); } catch {} }
    else { try { await item.setFlag(MOD_ID, MARKER, Array.from(new Set(arr)).sort()); } catch {} }
  }

  function processSheet(app, html) {
    const el = html?.jquery ? html[0] : html;
    if (!el) return;

    const item = app?.item ?? app?.object;
    const selectedSlots = readFlag(item);

    const selects = el.querySelectorAll?.(SELECTOR) ?? [];
    selects.forEach(sel => {
      const idx = getSlotIndex(sel);
      ensureOption(sel);
      if (idx != null && selectedSlots.includes(idx)) {
        const clone = sel.querySelector(`option[value=""][data-csc="${MARKER}"]`);
        if (clone) {
          for (const o of sel.options) o.selected = false;
          clone.selected = true;
        }
      }
    });

    el.addEventListener("change", async (ev) => {
      const t = ev.target;
      if (!(t instanceof HTMLSelectElement)) return;
      if (!t.name?.startsWith("system.runes.property")) return;
      const idx = getSlotIndex(t);
      if (idx == null) return;

      const chosen = t.selectedOptions?.[0];
      const choseSMI = chosen?.dataset?.csc === MARKER;

      const arr = readFlag(item);
      const has = arr.includes(idx);
      if (choseSMI && !has) arr.push(idx);
      if (!choseSMI && has) arr.splice(arr.indexOf(idx), 1);
      await writeFlag(item, arr);
    }, { passive: true });
  }

  function observe(app, html) {
    processSheet(app, html);
    const el = html?.jquery ? html[0] : html;
    if (!el) return;
    setTimeout(() => processSheet(app, html), 50);
    requestAnimationFrame(() => processSheet(app, html));
    const mo = new MutationObserver(() => processSheet(app, html));
    mo.observe(el, { childList: true, subtree: true });
    const closeEvt = "close" + app.constructor.name;
    const id = Hooks.on(closeEvt, () => { try { mo.disconnect(); } catch {} Hooks.off(closeEvt, id); });
  }

  Hooks.on("renderItemSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderItemSheet", (app, html) => observe(app, html));
  Hooks.on("renderActorSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderActorSheet", (app, html) => observe(app, html));
} else {
  console.warn("[CSC] already booted");
}
