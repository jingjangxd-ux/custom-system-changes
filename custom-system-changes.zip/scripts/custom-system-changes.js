
/**
 * v1.2.5 — Rename the existing blank option (value="") in weapon property rune selects.
 * Adds robust MutationObserver + delayed patch and verbose logging.
 */
const LABEL = "Specific Magic Weapon";
const SELECTOR = 'select[name^="system.runes.property"]';

function renameBlankInSelect(sel) {
  try {
    const opt = sel.querySelector('option[value=""]');
    if (!opt) return false;
    if (opt.textContent.trim() !== LABEL) {
      opt.textContent = LABEL;
      return true;
    }
  } catch (e) { console.warn("[CSC] renameBlankInSelect error:", e); }
  return false;
}

function patchRoot(root) {
  const el = root?.jquery ? root[0] : (root || document);
  const sels = el.querySelectorAll(SELECTOR);
  let changed = 0;
  for (const s of sels) if (renameBlankInSelect(s)) changed++;
  if (changed) console.log(`[CSC] Renamed blank rune option in ${changed} select(s).`);
}

function observeSheet(app, html) {
  const el = html?.jquery ? html[0] : html;
  if (!el) return;

  // Immediate and delayed attempts
  patchRoot(el);
  setTimeout(() => patchRoot(el), 50);
  requestAnimationFrame(() => patchRoot(el));

  // Observe dynamic changes
  const mo = new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === "childList") patchRoot(el);
    }
  });
  mo.observe(el, { childList: true, subtree: true });

  // Clean up when closed
  const closeEvent = "close" + app.constructor.name;
  const offId = Hooks.on(closeEvent, () => { try { mo.disconnect(); } catch {} Hooks.off(closeEvent, offId); });
}

// Global ready
Hooks.once("ready", () => {
  patchRoot(document);
  console.log("[CSC] Ready: attempting to rename blank rune option globally.");
});

// Item sheets (PF2e + generic)
Hooks.on("renderItemSheetPF2e", (app, html) => observeSheet(app, html));
Hooks.on("renderItemSheet", (app, html) => observeSheet(app, html));

// Also handle actor sheets just in case
Hooks.on("renderActorSheetPF2e", (app, html) => observeSheet(app, html));
Hooks.on("renderActorSheet", (app, html) => observeSheet(app, html));
