
// === Custom System Changes v1.3.1 ===
// Duplicate the blank rune option and label it "Specific Magic Item".
// Remember the user's choice by storing a flag on the Item, and restore it on render.
if (!window.__CSC_BOOTED__) {
  window.__CSC_BOOTED__ = true;
  console.log("%c[CSC] script loaded", "color:#7bd; font-weight:700");

  const MOD_ID  = "custom-system-changes";
  const LABEL   = "Specific Magic Item";
  const MARKER  = "smi";
  const SELECTOR = 'select[name^="system.runes.property"]';

  function ensureOption(sel) {
    const blank = sel.querySelector('option[value=""]');
    if (!blank) return null;
    let clone = sel.querySelector('option[value=""][data-csc="'+MARKER+'"]');
    if (!clone) {
      clone = blank.cloneNode(true);
      clone.textContent = LABEL;
      clone.dataset.csc = MARKER;
      blank.insertAdjacentElement("afterend", clone);
    } else {
      if (clone.textContent.trim() !== LABEL) clone.textContent = LABEL;
    }
    return clone;
  }

  function selectClone(sel) {
    const clone = sel.querySelector('option[value=""][data-csc="'+MARKER+'"]');
    if (!clone) return;
    // Ensure our clone is the visible selected option
    for (const o of sel.options) o.selected = false;
    clone.selected = true;
  }

  function processSheet(app, html) {
    const el = html?.jquery ? html[0] : html;
    if (!el) return;

    const selects = el.querySelectorAll?.(SELECTOR) ?? [];
    selects.forEach(s => ensureOption(s));

    // Restore selection if flag says so (getFlag is synchronous in Foundry)
    const item = app?.item ?? app?.object;
    if (item?.getFlag) {
      const flag = item.getFlag(MOD_ID, MARKER);
      if (flag) {
        selects.forEach(sel => {
          ensureOption(sel);
          selectClone(sel);
        });
      }
    }

    // Listen for changes and store/unset the flag
    el.addEventListener("change", async (ev) => {
      const t = ev.target;
      if (!(t instanceof HTMLSelectElement)) return;
      if (!t.name?.startsWith("system.runes.property")) return;
      const item = app?.item ?? app?.object;
      if (!item?.setFlag) return;

      const chosen = t.selectedOptions?.[0];
      const choseSMI = chosen?.dataset?.csc === MARKER;

      try {
        if (choseSMI) {
          await item.setFlag(MOD_ID, MARKER, true);
        } else {
          await item.unsetFlag(MOD_ID, MARKER);
        }
      } catch (e) {
        console.warn("[CSC] flag update failed:", e);
      }
    }, { passive: true });
  }

  function observe(app, html) {
    processSheet(app, html);
    const el = html?.jquery ? html[0] : html;
    if (!el) return;
    setTimeout(() => processSheet(app, html), 50);
    requestAnimationFrame(() => processSheet(app, html));
    const mo = new MutationObserver(() => processSheet(app, html));
    mo.observe(el, { childList: true, subtree: true });
    const closeEvt = "close" + app.constructor.name;
    const id = Hooks.on(closeEvt, () => { try { mo.disconnect(); } catch {} Hooks.off(closeEvt, id); });
  }

  Hooks.on("renderItemSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderItemSheet", (app, html) => observe(app, html));
  Hooks.on("renderActorSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderActorSheet", (app, html) => observe(app, html));
} else {
  console.warn("[CSC] already booted");
}
