
/** Custom System Changes — PF2e extras: add or rename a weapon property rune */
const MOD_ID = "custom-system-changes";

Hooks.once("init", () => {
  // Settings so you can choose the behavior without editing code
  game.settings.register(MOD_ID, "customRuneSlug", {
    name: "Custom Rune Slug",
    hint: "Slug to use for the new rune (if added).",
    scope: "world", config: true, type: String, default: "specific-magic-weapon"
  });
  game.settings.register(MOD_ID, "customRuneLabel", {
    name: "Custom Rune Label",
    hint: "Label to show in the selector.",
    scope: "world", config: true, type: String, default: "Specific Magic Weapon"
  });
  game.settings.register(MOD_ID, "fallbackRenameSlug", {
    name: "Fallback: Rename Existing Rune",
    hint: "If adding a new rune doesn't show up, which existing rune slug should be renamed to the custom label? Example: shifting, disrupting, ghost-touch, etc.",
    scope: "world", config: true, type: String, default: "shifting"
  });
});

function addTo(container, key, value) {
  if (!container) return false;
  try {
    if (container instanceof Map) {
      if (!container.has(key)) { container.set(key, value); return true; }
    } else if (Array.isArray(container)) {
      if (!container.includes(key)) { container.push(key); return true; }
    } else if (typeof container === "object") {
      if (!(key in container)) { container[key] = value; return true; }
    }
  } catch {}
  return false;
}

function setLabel(container, key, label) {
  if (!container) return false;
  try {
    if (container instanceof Map) {
      if (container.has(key)) {
        const v = container.get(key);
        if (typeof v === "string") container.set(key, label);
        else if (v && typeof v === "object") { v.label = label; container.set(key, v); }
        return true;
      }
    } else if (typeof container === "object" && key in container) {
      const v = container[key];
      if (typeof v === "string") container[key] = label;
      else if (v && typeof v === "object") v.label = label;
      return true;
    }
  } catch {}
  return false;
}

Hooks.once("ready", () => {
  const slug  = game.settings.get(MOD_ID, "customRuneSlug");
  const label = game.settings.get(MOD_ID, "customRuneLabel");
  const fallbackSlug = game.settings.get(MOD_ID, "fallbackRenameSlug");

  // Try to ADD a new rune key to possible PF2e containers
  const added =
    addTo(CONFIG.PF2E?.weaponPropertyRunes, slug, label) ||
    addTo(CONFIG.PF2E?.propertyRunes?.weapon, slug, label) ||
    addTo(CONFIG.PF2E?.runes?.weapon?.property, slug, { label });

  // If adding didn't work, try renaming an existing rune's label (UI-facing)
  if (!added && fallbackSlug) {
    const renamed =
      setLabel(CONFIG.PF2E?.weaponPropertyRunes, fallbackSlug, label) ||
      setLabel(CONFIG.PF2E?.propertyRunes?.weapon, fallbackSlug, label) ||
      setLabel(CONFIG.PF2E?.runes?.weapon?.property, fallbackSlug, label);
    console.log(`[CSC] Rune add failed; renamed '${fallbackSlug}' to '${label}' →`, renamed);
  } else {
    console.log(`[CSC] Added custom weapon property rune '${slug}' as '${label}'`);
  }

  // Force re-render any open actor sheets so the selector refreshes
  for (const app of Object.values(ui.windows)) {
    if (app?.rendered && app.actor?.type === "character") app.render(true);
  }
});
