
// === Custom System Changes v1.2.8 ===
// Behavior: in any PF2e weapon property rune <select>, clone the blank option (value="")
// and insert a second option labeled "Specific Magic Weapon" right after it. The cloned
// option keeps value="" so it behaves like the blank choice.
if (!window.__CSC_BOOTED__) {
  window.__CSC_BOOTED__ = true;
  console.log("%c[CSC] script loaded", "color:#7bd; font-weight:700");

  const LABEL = "Specific Magic Weapon";
  const SELECTOR = 'select[name^="system.runes.property"]';

  function applyToSelect(sel) {
    try {
      const blank = sel.querySelector('option[value=""]');
      if (!blank) return false;

      // If our labeled duplicate already exists, do nothing
      const exists = Array.from(sel.options).some(o => o.value === "" && o.dataset.csc === "smw");
      if (exists) return false;

      // Clone the blank option, keep value="", set label, and mark it
      const clone = blank.cloneNode(true);
      clone.textContent = LABEL;
      clone.dataset.csc = "smw";

      // Insert right after the original blank option
      blank.insertAdjacentElement("afterend", clone);
      return true;
    } catch (e) {
      console.warn("[CSC] applyToSelect error:", e);
      return false;
    }
  }

  function processRoot(root=document) {
    const el = root?.jquery ? root[0] : root;
    const sels = el.querySelectorAll?.(SELECTOR) ?? [];
    let changed = 0;
    for (const s of sels) if (applyToSelect(s)) changed++;
    if (changed) console.log(`[CSC] Inserted labeled blank duplicate in ${changed} select(s).`);
  }

  function observe(app, html) {
    const el = html?.jquery ? html[0] : html;
    if (!el) return;
    processRoot(el);
    // Multiple passes to survive late render
    setTimeout(() => processRoot(el), 50);
    requestAnimationFrame(() => processRoot(el));
    // Observe dynamic changes inside this sheet
    const mo = new MutationObserver(() => processRoot(el));
    mo.observe(el, { childList: true, subtree: true });
    // Cleanup on close
    const closeEvt = "close" + app.constructor.name;
    const id = Hooks.on(closeEvt, () => { try { mo.disconnect(); } catch {} Hooks.off(closeEvt, id); });
  }

  Hooks.once("ready", () => {
    console.log("[CSC] ready fired");
    processRoot(document);
  });

  Hooks.on("renderItemSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderItemSheet", (app, html) => observe(app, html));
  Hooks.on("renderActorSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderActorSheet", (app, html) => observe(app, html));
} else {
  console.warn("[CSC] already booted");
}
