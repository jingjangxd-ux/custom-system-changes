
/** Custom System Changes - add a custom weapon property rune to PF2e */
Hooks.once("init", () => {
  try {
    const slug = "specific-magic-weapon";
    const label = game.i18n.localize("CSC.Rune.SpecificMagicWeapon") || "Specific Magic Weapon";

    /** helper: add key/value into a mapping-like object safely */
    const addTo = (container, key, value) => {
      if (!container) return;
      if (Array.isArray(container)) {
        if (!container.includes(key)) container.push(key);
      } else if (container instanceof Map) {
        if (!container.has(key)) container.set(key, value);
      } else if (typeof container === "object") {
        if (!(key in container)) container[key] = value;
      }
    };

    // PF2e has used different structures across versions; update any we find.
    addTo(CONFIG.PF2E?.weaponPropertyRunes, slug, label);                 // classic mapping
    addTo(CONFIG.PF2E?.propertyRunes?.weapon, slug, label);               // alt legacy
    addTo(CONFIG.PF2E?.runes?.weapon?.property, slug, { label });         // v5+ style

    console.log("[Custom System Changes] Added weapon property rune:", slug, "→", label);
  } catch (err) {
    console.error("[Custom System Changes] Failed to add custom rune", err);
  }
});
