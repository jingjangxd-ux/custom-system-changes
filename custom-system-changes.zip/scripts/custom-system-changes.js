
// === Custom System Changes v1.2.7 ===
if (!window.__CSC_BOOTED__) {
  window.__CSC_BOOTED__ = true;
  console.log("%c[CSC] script loaded", "color:#7bd; font-weight:700");

  const LABEL = "Specific Magic Weapon";
  const SELECTOR = 'select[name^="system.runes.property"]';

  function renameOnce(root=document) {
    const el = root?.jquery ? root[0] : root;
    const sels = el.querySelectorAll?.(SELECTOR) ?? [];
    let changed = 0;
    for (const s of sels) {
      const opt = s.querySelector('option[value=\"\"]');
      if (opt && opt.textContent.trim() !== LABEL) {
        opt.textContent = LABEL;
        changed++;
      }
    }
    if (changed) console.log(`[CSC] Renamed blank option in ${changed} select(s).`);
  }

  function observe(app, html) {
    const el = html?.jquery ? html[0] : html;
    if (!el) return;
    renameOnce(el);
    setTimeout(() => renameOnce(el), 50);
    requestAnimationFrame(() => renameOnce(el));
    const mo = new MutationObserver(() => renameOnce(el));
    mo.observe(el, { childList: true, subtree: true });
    const closeEvt = "close" + app.constructor.name;
    const id = Hooks.on(closeEvt, () => { try { mo.disconnect(); } catch {} Hooks.off(closeEvt, id); });
  }

  Hooks.once("ready", () => {
    console.log("[CSC] ready fired");
    renameOnce(document);
    if (ui?.notifications) ui.notifications.info("Custom System Changes: JS active", { permanent: false });
  });

  Hooks.on("renderItemSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderItemSheet", (app, html) => observe(app, html));
  Hooks.on("renderActorSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderActorSheet", (app, html) => observe(app, html));
} else {
  console.warn("[CSC] already booted");
}
