
const MOD_ID = "custom-system-changes";
const FLAG_PATH = "customRuneSelected"; // boolean flag on the item

Hooks.once("init", () => {
  game.settings.register(MOD_ID, "customRuneSlug", {
    name: "Custom Rune Slug (UI only)",
    hint: "Internal value for the UI option. Example: csc-specific-magic-weapon",
    scope: "world", config: true, type: String, default: "csc-specific-magic-weapon"
  });
  game.settings.register(MOD_ID, "customRuneLabel", {
    name: "Custom Rune Label",
    hint: "What the dropdown should display.",
    scope: "world", config: true, type: String, default: "Specific Magic Weapon"
  });
  game.settings.register(MOD_ID, "mapToRuneSlug", {
    name: "Map UI Option To This Real Rune",
    hint: "Which existing PF2e property rune should be stored when the custom option is chosen (e.g. shifting, ghostTouch, disrupting, etc.). Must match the <option value> slug.",
    scope: "world", config: true, type: String, default: "shifting"
  });
});

function enhanceWeaponRuneSelectors(app, html) {
  try {
    const item = app?.item;
    if (!item || item.type !== "weapon") return;
    const customSlug = game.settings.get(MOD_ID, "customRuneSlug");
    const customLabel = game.settings.get(MOD_ID, "customRuneLabel");
    const mapSlug = game.settings.get(MOD_ID, "mapToRuneSlug");

    const selects = html[0]?.querySelectorAll('select[name^="system.runes.property"]');
    if (!selects || !selects.length) return;

    for (const sel of selects) {
      if (![...sel.options].some(o => o.value === customSlug)) {
        const opt = document.createElement("option");
        opt.value = customSlug;
        opt.textContent = customLabel;
        sel.appendChild(opt);
      }
    }

    item.getFlag(MOD_ID, FLAG_PATH).then(flag => {
      if (!flag) return;
      for (const sel of selects) {
        if (sel.value === mapSlug) sel.value = customSlug;
      }
    });
  } catch (err) {
    console.error("[CSC] enhanceWeaponRuneSelectors failed:", err);
  }
}

Hooks.on("renderItemSheetPF2e", enhanceWeaponRuneSelectors);

Hooks.on("preUpdateItem", async (item, change, options, userId) => {
  try {
    if (item.type !== "weapon") return;
    const customSlug = game.settings.get(MOD_ID, "customRuneSlug");
    const mapSlug = game.settings.get(MOD_ID, "mapToRuneSlug");

    let props = change?.system?.runes?.property;
    if (!props) return;
    if (!Array.isArray(props)) props = [props];

    let touched = false;
    for (let i = 0; i < props.length; i++) {
      if (props[i] === customSlug) {
        props[i] = mapSlug;
        touched = true;
      }
    }

    if (touched) {
      change.system = change.system ?? {};
      change.system.runes = change.system.runes ?? {};
      change.system.runes.property = props;

      const flags = change.flags ?? (change.flags = {});
      flags[MOD_ID] = flags[MOD_ID] ?? {};
      flags[MOD_ID][FLAG_PATH] = true;
    } else {
      const arr = change?.system?.runes?.property;
      if (Array.isArray(arr) && !arr.includes(mapSlug)) {
        const flags = change.flags ?? (change.flags = {});
        flags[MOD_ID] = flags[MOD_ID] ?? {};
        flags[MOD_ID][FLAG_PATH] = false;
      }
    }
  } catch (err) {
    console.error("[CSC] preUpdateItem mapping failed:", err);
  }
});
