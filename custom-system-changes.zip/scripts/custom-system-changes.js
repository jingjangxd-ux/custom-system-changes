
// === Custom System Changes v1.3.0 ===
// Duplicate the blank rune option and label it "Specific Magic Item".
// Remember the user's choice by storing a flag on the Item, and restore it on render.
if (!window.__CSC_BOOTED__) {
  window.__CSC_BOOTED__ = true;
  console.log("%c[CSC] script loaded", "color:#7bd; font-weight:700");

  const MOD_ID  = "custom-system-changes";
  const LABEL   = "Specific Magic Item";
  const MARKER  = "smi";
  const SELECTOR = 'select[name^="system.runes.property"]';

  function ensureOption(sel) {
    const blank = sel.querySelector('option[value=""]');
    if (!blank) return null;
    let clone = sel.querySelector('option[value=""][data-csc="'+MARKER+'"]');
    if (!clone) {
      clone = blank.cloneNode(true);
      clone.textContent = LABEL;
      clone.dataset.csc = MARKER;
      blank.insertAdjacentElement("afterend", clone);
    } else {
      // keep label in case something reset it
      if (clone.textContent.trim() !== LABEL) clone.textContent = LABEL;
    }
    return clone;
  }

  function processSheet(app, html) {
    const el = html?.jquery ? html[0] : html;
    if (!el) return;

    // 1) Insert/refresh our option(s)
    const selects = el.querySelectorAll?.(SELECTOR) ?? [];
    selects.forEach(s => ensureOption(s));

    // 2) Restore selection if flag says so
    const item = app?.item ?? app?.object;
    if (item?.getFlag) {
      item.getFlag(MOD_ID, MARKER)?.then(flag => {
        if (!flag) return;
        selects.forEach(sel => {
          const clone = ensureOption(sel);
          if (clone) {
            // select our labeled duplicate (value is "", same as blank)
            sel.value = ""; // keep model consistent
            // Force the UI to point to the clone
            for (const o of sel.options) o.selected = false;
            clone.selected = true;
          }
        });
      }).catch(()=>{});
    }

    // 3) Listen for changes and store the flag accordingly
    el.addEventListener("change", async (ev) => {
      const t = ev.target;
      if (!(t instanceof HTMLSelectElement)) return;
      if (!t.name?.startsWith("system.runes.property")) return;
      const item = app?.item ?? app?.object;
      if (!item?.setFlag) return;

      const chosen = t.selectedOptions?.[0];
      const choseSMI = chosen?.dataset?.csc === MARKER;

      try {
        if (choseSMI) {
          await item.setFlag(MOD_ID, MARKER, true);
        } else {
          await item.unsetFlag(MOD_ID, MARKER);
        }
      } catch (e) {
        console.warn("[CSC] flag update failed:", e);
      }
    }, { passive: true });
  }

  function observe(app, html) {
    processSheet(app, html);
    const el = html?.jquery ? html[0] : html;
    if (!el) return;
    // Re-apply after late renders
    setTimeout(() => processSheet(app, html), 50);
    requestAnimationFrame(() => processSheet(app, html));
    // Observe mutations within the sheet
    const mo = new MutationObserver(() => processSheet(app, html));
    mo.observe(el, { childList: true, subtree: true });
    const closeEvt = "close" + app.constructor.name;
    const id = Hooks.on(closeEvt, () => { try { mo.disconnect(); } catch {} Hooks.off(closeEvt, id); });
  }

  Hooks.on("renderItemSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderItemSheet", (app, html) => observe(app, html));
  // Some themes reuse actor renders; keep these to be safe
  Hooks.on("renderActorSheetPF2e", (app, html) => observe(app, html));
  Hooks.on("renderActorSheet", (app, html) => observe(app, html));
} else {
  console.warn("[CSC] already booted");
}
