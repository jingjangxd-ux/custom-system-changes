
/**
 * v1.2.4 — Rename the existing blank option (value="") in weapon property rune selects
 * to "Specific Magic Weapon". No duplication; the value remains "" (no rune).
 */
const LABEL = "Specific Magic Weapon";

function renameBlankUnder(root) {
  // Accept HTMLElement or jQuery
  const el = root?.jquery ? root[0] : (root || document);
  const selects = el.querySelectorAll('select[name^="system.runes.property"]');
  for (const sel of selects) {
    const opt = sel.querySelector('option[value=""]');
    if (opt && opt.textContent.trim() !== LABEL) {
      opt.textContent = LABEL;
    }
  }
}

Hooks.once("ready", () => renameBlankUnder(document));

Hooks.on("renderItemSheetPF2e", (_app, html) => renameBlankUnder(html));
Hooks.on("renderItemSheet", (_app, html) => renameBlankUnder(html));

/* Reapply if the sheet updates dynamically */
Hooks.on("updateItem", (_item, _changes, _opts, userId) => {
  if (game.user?.id !== userId) return;
  for (const app of Object.values(ui.windows)) {
    if (app?.rendered && app.constructor.name.includes("ItemSheet")) renameBlankUnder(app.element);
  }
});
