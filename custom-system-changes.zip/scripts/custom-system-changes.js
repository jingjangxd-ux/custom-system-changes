
/**
 * v1.2.3 — Inject a duplicate of the blank rune option labeled "Specific Magic Weapon".
 * Fix: run on Item sheets (weapon options live there), not just Actor sheets.
 * Also: handle dynamic rerenders with a MutationObserver.
 */
const LABEL = "Specific Magic Weapon";

/** Resolve a root element from either HTMLElement or jQuery */
function rootEl(root) {
  if (!root) return document;
  if (root instanceof HTMLElement) return root;
  if (root.jquery) return root[0];
  return document;
}

/** Perform injection for all matching selects under given root */
function injectUnder(root) {
  const el = rootEl(root);
  const selects = el.querySelectorAll('select[name^="system.runes.property"]');
  for (const sel of selects) {
    // Don't duplicate endlessly
    const already = Array.from(sel.options).some(o => o.value === "" && o.textContent.trim() === LABEL);
    const blank = sel.querySelector('option[value=""]');
    if (!blank || already) continue;
    const clone = blank.cloneNode(true);
    clone.textContent = LABEL;
    blank.insertAdjacentElement("afterend", clone);
  }
}

/** Observe re-renders and re-apply injection */
function observeAndInject(app, html) {
  const el = rootEl(html);
  if (!el) return;
  // Initial pass
  injectUnder(el);
  // Watch for changes inside this sheet
  const obs = new MutationObserver(() => injectUnder(el));
  obs.observe(el, { subtree: true, childList: true });
  // Clean up when app closes
  const closeHook = Hooks.on("close" + app.constructor.name, () => { try { obs.disconnect(); } catch {} Hooks.off("close" + app.constructor.name, closeHook); });
}

// Initial once-ready for anything already on screen
Hooks.once("ready", () => {
  injectUnder(document);
});

// Handle PF2e classed hooks if present
Hooks.on("renderActorSheetPF2e", (app, html) => observeAndInject(app, html));
Hooks.on("renderItemSheetPF2e", (app, html) => observeAndInject(app, html));

// Fallback generic hooks (some themes use these)
Hooks.on("renderActorSheet", (app, html) => observeAndInject(app, html));
Hooks.on("renderItemSheet", (app, html) => observeAndInject(app, html));
